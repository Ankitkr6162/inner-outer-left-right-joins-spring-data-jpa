package io.spring.data.jpa.joins.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan("io.spring.data.jpa.joins.api.entities") 
@EnableJpaRepositories("io.spring.data.jpa.joins.api.repository")
public class JoinsSpringDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoinsSpringDataJpaApplication.class, args);
	}

}
