package io.spring.data.jpa.joins.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import io.spring.data.jpa.joins.api.dto.DeptEmpDto;
import io.spring.data.jpa.joins.api.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("SELECT new  io.spring.data.jpa.joins.api.dto.DeptEmpDto(d.name, e.name, e.email, e.address) "
			+ "FROM Department d INNER JOIN d.employees e")
	public List<DeptEmpDto> fetchEmpDeptDataInnerJoin();

	@Query("SELECT new io.spring.data.jpa.joins.api.dto.DeptEmpDto(d.name, e.name, e.email, e.address) "
			+ "FROM Department d, Employee e")
 public	List<DeptEmpDto> fetchEmpDeptDataCrossJoin();

}
