package io.spring.data.jpa.joins.api.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import io.spring.data.jpa.joins.api.dto.DeptEmpDto;
import io.spring.data.jpa.joins.api.entities.Department;

public interface DepartmentRepository extends JpaRepository<Department, Integer> {

	@Transactional
	@Modifying
	@Query("SELECT new io.spring.data.jpa.joins.api.dto.DeptEmpDto(d.name, e.name, e.email, e.address) "
			+ "FROM Department d LEFT JOIN d.employees e")
	List<DeptEmpDto> fetchEmpDeptDataLeftJoin();

	@Transactional
	@Modifying
	@Query("SELECT new io.spring.data.jpa.joins.api.dto.DeptEmpDto(d.name, e.name, e.email, e.address) "
			+ "FROM Department d RIGHT JOIN d.employees e" )
	List<DeptEmpDto> fetchEmpDeptDataRightJoin();

}
