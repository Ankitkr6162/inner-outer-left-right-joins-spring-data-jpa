package io.spring.data.jpa.joins.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoinsSprngDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
